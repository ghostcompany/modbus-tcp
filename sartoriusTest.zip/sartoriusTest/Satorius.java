/*
 * Decompiled with CFR 0_118.
 * 
 * Could not load the following classes:
 *  net.wimpi.modbus.io.ModbusTCPTransaction
 *  net.wimpi.modbus.msg.ModbusRequest
 *  net.wimpi.modbus.msg.ModbusResponse
 *  net.wimpi.modbus.msg.ReadInputRegistersRequest
 *  net.wimpi.modbus.msg.ReadInputRegistersResponse
 *  net.wimpi.modbus.net.TCPMasterConnection
 */
//package ab;

import pkg.*;

import java.io.PrintStream;
import java.io.Serializable;
import java.net.InetAddress;
import net.wimpi.modbus.io.ModbusTCPTransaction;
import net.wimpi.modbus.msg.ModbusRequest;
import net.wimpi.modbus.msg.ModbusResponse;
import net.wimpi.modbus.msg.ReadInputRegistersRequest;
import net.wimpi.modbus.msg.ReadInputRegistersResponse;
import net.wimpi.modbus.net.TCPMasterConnection;

public class Satorius {
    private static final long serialVersionUID = 8907188755122105165L;
    private DatabaseManager db = DatabaseManager.getInstance();
    private static Satorius instance = new Satorius();
    private TCPMasterConnection conn1 = null;
    private TCPMasterConnection conn2 = null;
	private InetAddress addr = null;
    private Thread th = null;
    private boolean jalan = true;
	private boolean flagFirst = false;
    //private static String ip = "10.103.78.27";
    private static String ip1 = "127.0.0.1";
    private static String ip2 = "127.0.0.1";

    private Satorius() {
    }

    private void connect1() throws Exception {
        byte[] b = new byte[]{0, 0, 0, 0};
        String[] split = ip1.split("\\.");
        if (split.length == 4) {
            try {
                byte b1 = Byte.parseByte(split[0]);
                byte b2 = Byte.parseByte(split[1]);
                byte b3 = Byte.parseByte(split[2]);
                byte b4 = Byte.parseByte(split[3]);
                b[0] = b1;
                b[1] = b2;
                b[2] = b3;
                b[3] = b4;
            }
            catch (Exception e) {
                System.out.println("Incorrect ip " + ip1);
            }
        }
        InetAddress addr = InetAddress.getByAddress(b);
        this.conn1 = new TCPMasterConnection(addr);
        this.conn1.setPort(502);
        this.conn1.connect();
    }
    private void connect2() throws Exception {
        byte[] b = new byte[]{0, 0, 0, 0};
        String[] split = ip2.split("\\.");
        if (split.length == 4) {
            try {
                byte b1 = Byte.parseByte(split[0]);
                byte b2 = Byte.parseByte(split[1]);
                byte b3 = Byte.parseByte(split[2]);
                byte b4 = Byte.parseByte(split[3]);
                b[0] = b1;
                b[1] = b2;
                b[2] = b3;
                b[3] = b4;
            }
            catch (Exception e) {
                System.out.println("Incorrect ip " + ip2);
            }
        }
        InetAddress addr = InetAddress.getByAddress(b);
        this.conn2 = new TCPMasterConnection(addr);
        this.conn2.setPort(503);
        this.conn2.connect();
    }

    public static Satorius getInstance() {
        return instance;
    }

    private int bacaAlamat1(int alamat,TCPMasterConnection con) throws Exception {
        int hasil = 0;
        ReadInputRegistersRequest req = new ReadInputRegistersRequest(alamat, 1);
        ModbusTCPTransaction trans = new ModbusTCPTransaction(con);
        trans.setRequest((ModbusRequest)req);
        trans.setCheckingValidity(true);
        trans.setRetries(10);
        trans.execute();
        ReadInputRegistersResponse res = (ReadInputRegistersResponse)trans.getResponse();
        hasil = res.getRegisterValue(0);
        return hasil;
    }

    private void read() {
        try {
            if (this.conn1 == null || !this.conn1.isConnected()) {
				this.connect1();
            }
            if (this.conn2 == null || !this.conn2.isConnected()) {
                this.connect2();
            }
        }
        catch (Exception e1) {
            e1.printStackTrace();
        }
        try {
            int wt = this.bacaAlamat1(17, this.conn1);
            System.out.println(wt);
            this.db.setTimbangan(wt, 1);
        }
        catch (Exception e) {
            e.printStackTrace();
            System.out.println("fail1");
			try {
				this.connect1();
			}
			catch (Exception e2) {
			}
        }
        try {
            int wk = this.bacaAlamat1(17, this.conn2);
            System.out.println(wk);
            this.db.setTimbangan(wk, 2);
        } catch(Exception ee){
            ee.printStackTrace();
            System.out.println("fail2");
            try {
                this.connect2();
            }
            catch (Exception e2) {
            }
        }
    }

    public void start() {
        if (this.th != null) {
            return;
        }
        this.th = new Thread(new Runnable(){

            @Override
            public void run() {
                while (Satorius.this.jalan) {
                    try {
                        Satorius.this.read();
                        Thread.sleep(1000);
                        continue;
                    }
                    catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        this.th.start();
    }

    public void stop() {
        this.jalan = false;
    }
	
    public static void main(String[] args) {
	System.out.println("hello javatpoint");
        if (args.length > 0) {
            ip1 = args[0];
            ip2 = args[1];
        }
        Satorius sat = new Satorius();
        sat.start();
    }

}

